import {Birds, Fishs, Cats} from "./Bird_Fish_Cat"
    let Karkushas = new Birds;
    let Willys = new Fishs;
    let Sams = new Cats;
    
    console.log(Sams.tail);
    console.log(Sams.move);
    console.log(Sams.voice());
    console.log(Willys.voice());
    console.log(Sams.beauty);
   console.log(Karkushas.voice());
   
    
    