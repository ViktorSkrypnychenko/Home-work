export interface Animals {
    beauty?:string;
    tail: boolean;
    move: string;
    voice: ()=> string;
}